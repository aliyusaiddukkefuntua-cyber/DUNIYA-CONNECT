# DUNIYA CONNECT — Firebase Authentication

Wannan Flutter project yana haɗa rajista da shiga da **Firebase Authentication (Email/Password)**. Yana aiki a Android, Web/Chrome da Windows bayan an saita Firebase project ɗinka.

## Muhimmin abu
Ba za a iya kunna Firebase ainihi daga source code kawai ba. Kana buƙatar Firebase project naka, sannan ka yi saitin da ke ƙasa. Kada ka raba kalmar sirri ko private credentials.

## 1. Ƙirƙiri Firebase project
1. Je zuwa https://console.firebase.google.com/ sannan ka ƙirƙiri project mai suna misali `duniya-connect`.
2. A cikin Firebase Console, buɗe **Authentication → Get started → Sign-in method**.
3. Kunna **Email/Password** sannan ka ajiye.
4. Ƙara app ɗinka a Firebase project: Android package ID, Web app, da/ko Windows app gwargwadon inda za ka gudanar da shi. Ka bi umarnin Firebase na kowane platform.

## 2. Saita FlutterFire a Windows 10
Ka tabbatar Flutter da Git suna aiki. Buɗe Command Prompt/PowerShell a cikin wannan folder:

```bat
flutter create . --platforms=android,web,windows
flutter pub get
dart pub global activate flutterfire_cli
firebase login
flutterfire configure
```

A lokacin `flutterfire configure`, zaɓi Firebase project ɗinka da platforms ɗin da za ka yi amfani da su. Wannan umarni zai ƙirƙiri `lib/firebase_options.dart` da app IDs masu dacewa. **Kada ka ƙirƙiri wannan file da hannu ko ka yi amfani da saitin wani mutum.** Idan `firebase` command bai samu ba, bi umarnin shigar Firebase CLI: https://firebase.google.com/docs/cli

## 3. Gudanar da app

Web/Chrome:
```bat
flutter run -d chrome
```

Duba na'urorin da ake da su:
```bat
flutter devices
```

Android emulator ko Windows desktop (idan an kunna desktop support):
```bat
flutter run -d <device-id>
```

## Abin da aka haɗa
- Rajista ta ainihi ta imel da kalmar sirri ta `createUserWithEmailAndPassword`.
- Ajiye sunan mai amfani a Firebase profile da aika imel na tabbatarwa.
- Shiga ta `signInWithEmailAndPassword`.
- `authStateChanges` domin gane ko mai amfani ya shiga.
- Saƙonnin kuskuren Firebase da maɓallin fita (sign out).

## Tsaro da iyakoki
- Wannan yana kunna **authentication** ne kawai; posts, chat, videos da groups har yanzu demo ne kuma ba su da backend.
- Ka saita Firebase Security Rules kafin ka adana bayanan masu amfani a Firestore/Storage.
- Kada ka saka service-account private key a cikin app.
